<?php 

    require_once('includes/functions.php');
    require_once('includes/connection.php');
    get_record();

?>