<?php 

    require_once('includes/functions.php');
    require_once('includes/connection.php');
    display_record();


?>