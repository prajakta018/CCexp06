<?php 

        $con = mysqli_connect('localhost','root','','testing');
        if(!$con)
        {
            die (' Please Your Connectino '.mysqli_error());
        }

?>