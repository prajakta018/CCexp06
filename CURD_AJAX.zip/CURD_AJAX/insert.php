<?php 

    require_once('includes/functions.php');
    InsertRecord();

?>